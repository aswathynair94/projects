package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import page.LoginPage;
import util.ConfigReader;

public class Logintest {

	protected WebDriver driver;
	public LoginPage loginpage;
	private static final ConfigReader configReader = new ConfigReader();
	public static final String ID = configReader.getEmail();
	public static final String PASSWORD = configReader.getPassword();
	public static final String INVALID_EMAIL = configReader.invalidEmail();
	public static final String INVALID_PASSWORD = configReader.getPassword();
	public static final String BROWSER = configReader.getBrowser();
	public static final String DRIVER_PATH = configReader.getDriverPath();
	public static final String BASE_URL = configReader.getBaseURL();
	public static final String INVALID_CREDENTIALS = configReader.getinvalidCredentials();
	public static final String HITS_URL = configReader.getHitsURL();

	// For now, I just implemented it for Chrome and it could also be implemented with different browsers.
	@BeforeTest
	public void setUp(){
		System.setProperty("webdriver.chrome.driver","//Users//jithinnair//Desktop//chromedriver");
		driver = new ChromeDriver();
		driver.get(BASE_URL);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		loginpage = PageFactory.initElements(driver, LoginPage.class);
	}
	
	@BeforeMethod
	public void initURL() {
		driver.get(BASE_URL);
		//loginpage.clearFields();
	}
	
	@Test(priority = 1, enabled = true, description = "TC01: Verify the user login with valid credentials")
	public void validCredentials() throws InterruptedException{
		loginpage.setEmailField(ID);
		loginpage.setPasswordField(PASSWORD);
		loginpage.setLoginButton();
		
		String actualMessage = driver.getTitle();
		System.out.println(actualMessage);
		
		//Thread.sleep(2000);
		driver.findElement(By.className("bp3-button-text")).click();
		//Thread.sleep(2000);
		//driver.get(HITS_URL);
		//Selecting HITS
		driver.findElement(By.xpath("//body/div[@id='root']/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[2]")).click();
		
		//Selecting "PURE"
		driver.findElement(By.xpath("//tbody/tr[@id='product-list-row-hits-pure-0-0-0']/td[1]/label[1]/span[1]")).click();
		//Clicking the "Purchase selected products button""
		driver.findElement(By.id("product-browsing-top-buy-selected")).click();
		//Thread.sleep(3000);
		
		//yearly subscription
		//driver.findElement(By.xpath("/html/body/div[7]/div/div[2]/div/div/div[3]/div[1]/div/div[2]/label/span[2]")).click();
		
		// We are targeting only one certain code in explicit wait, so performance issues will not be impacted. 
		@SuppressWarnings("unused")
		WebDriverWait w = new WebDriverWait(driver, 5);
		
		//monthly subscription : As we want the product to be "SMTH purchase type" we have to select the monthly subscription plan 
		driver.findElement(By.xpath("/html[1]/body[1]/div[7]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/label[1]/span[2]")).click();
		
		Thread.sleep(2000);
		// Finally adding the products to the cart
		driver.findElement(By.id("products-purchase-dialog-buy-button")).click();
		
		// Clicking the user account to logoff
		driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div[1]/div/div[2]/span[2]/span/button/span[2]")).click();
		Thread.sleep(3000);
		
		// Signing out of the Tickvault
		driver.findElement(By.xpath("//div[contains(text(),'Log out')]")).click();
		
		// Relogin the site using the same userid and password
		driver.get(BASE_URL);
		loginpage.setEmailField(ID);
		loginpage.setPasswordField(PASSWORD);
		loginpage.setLoginButton();
		
		// Accessing the cart icon to check the purchased products are still in the cart
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/button[1]")).click();
	}
}

