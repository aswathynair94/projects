package util;





import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/**
 * Class reads base settings from the config.properties file
 */
public class ConfigReader {
	private String id = "";
	private String password = "";
	private String invalidEmail = "";
	private String invalidPassword = "";
	private String driverPath = "";
	private String browser ="";
	private String baseURL = "";
	private String invalidCredentials;
	private String hits_url = "";

	/**
	 * Class constructor loads settings from the file and saves to fields
	 */
	public ConfigReader() {
		FileInputStream fis;
		try {
			fis = new FileInputStream("config.properties");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("Cant't read config.properties file!");
			return;
		}
		Properties p = new Properties();
		try {
			p.load(fis);
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Cant't read config.properties file!");
			return;
		}
		
		id = p.getProperty("ID");
		invalidEmail = p.getProperty("INVALID_EMAIL");
		invalidPassword = p.getProperty("INVALID_PASSWORD");
		password = p.getProperty("PASSWORD");
		browser = p.getProperty("BROWSER");
		driverPath = p.getProperty("DRIVER_PATH");
		baseURL = p.getProperty("BASE_URL");
		invalidCredentials = p.getProperty("INVALID_CREDENTIALS");
		hits_url = p.getProperty("HITS_URL");
		
	}
	
	public String getEmail() {
		return id;
	}
	
	public String getPassword() {
		return password;
	}

	public String getBrowser() {
		return browser;
	}
	
	public String getDriverPath() {
		return driverPath;
	}
	
	public String getHitsURL() {
		return hits_url;
	}
	public String invalidPassword() {
		return invalidPassword;
	}

	public String invalidEmail() {
		return invalidEmail;
	}

	public String getBaseURL() {
		return baseURL;
	}

	public String getinvalidCredentials() {
		return invalidCredentials;
	}

}