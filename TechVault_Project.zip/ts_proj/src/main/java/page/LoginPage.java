package page;


	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.FindBy;

	public class LoginPage {
	protected WebDriver driver;
		 
		 @FindBy(id ="email")
		 public WebElement emailField;
		 
		 @FindBy(id = "password")
		 private WebElement passwordField;
		   
		 @FindBy(id = "signinBtn")
		 private WebElement loginButton;
		 
		 
		 // catalog
		 
		 @FindBy(className = "bp3-button-text")
		 private WebElement Catalog;
		 
		 @FindBy(id = "categories-list-category-hits")
		 private WebElement HITS;
		 
		 @FindBy(id = "product-browsing-top-search")
		 private WebElement HITSpureexchange;
		 
		 
		 
		 
		
		 public LoginPage (WebDriver driver) {
				this.driver = driver;
		 }
		 
		 public void setEmailField(String email) {
				emailField.clear();
				emailField.sendKeys(email);
		 }
			
		 public void setPasswordField(String password) {
				passwordField.clear();
				passwordField.sendKeys(password);
		 }
		 
		 public void setLoginButton() {
			   loginButton.click();
		 }
		  
		
	}
	 
